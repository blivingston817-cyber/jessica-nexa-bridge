import Fastify from 'fastify';
import fastifyFormBody from '@fastify/formbody';
import fastifyWs from '@fastify/websocket';
import WebSocket from 'ws';
import fetch from 'node-fetch';
import dotenv from 'dotenv';
dotenv.config();

const PORT = process.env.PORT || 3000;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const BRANDYN_CELL = '+12147897527';
const BRANDYN_EMAIL = 'blivingston@nexalending.com';
const TWILIO_ACCOUNT_SID = process.env.TWILIO_ACCOUNT_SID;
const TWILIO_AUTH_TOKEN = process.env.TWILIO_AUTH_TOKEN;
const TWILIO_PHONE_NUMBER = process.env.TWILIO_PHONE_NUMBER || '+18339883514';
const LEADFLOW_APP_ID = process.env.LEADFLOW_APP_ID || '69cfe4f5a8d6d5273ce84a33';
const MORTGAGEFLOW_APP_ID = process.env.MORTGAGEFLOW_APP_ID || '69bfd95d92a306f5b08f1db5';
const BASE44_API_KEY = process.env.BASE44_API_KEY;
const BASE44_WEBHOOK_URL = process.env.BASE44_WEBHOOK_URL; // your vapiWebhook URL

const SYSTEM_PROMPT = `You are Jessica, a professional and friendly mortgage intake agent for NEXA Lending. Your job is to gather important financial information from callers so that a loan officer can follow up with them. Be warm, conversational, and patient. Ask one question at a time. Keep your responses concise and natural — this is a phone call.

OPENING FLOW:
- Greet the caller and ask how you can help.
- Most callers are calling back because they recently received a call from NEXA Lending. If they mention they got a call, or if they seem unsure why they are calling, say something like: "Yes! We recently reached out because it looks like you had inquired about some mortgage options. I just wanted to follow up and see how we could help. Do you have a couple of minutes for me to ask a few quick questions so we can find the best solution for you?"
- Then naturally transition into the intake questions below.

INTAKE QUESTIONS (ask one at a time):
1. What are your financial goals, and how much cash are you looking to access?
2. What do you currently owe on your home?
3. What is your current interest rate?
4. What is your current monthly mortgage payment?
5. Do you escrow your property taxes and homeowners insurance?
   - How much do you spend per year on property taxes?
   - How much do you spend per year on homeowners insurance?
6. Where do you currently work?
7. How long have you been working there?
8. What is your current position/title?
9. What is your annual salary?

Based on their employment situation:
- If SELF-EMPLOYED: How long self-employed? Taxable income last year (after deductions)? Year before that? (If they write off a lot, mention NEXA has Bank Statement Loans or P&L Statement Loans signed by a CPA.)
- If RETIRED: Social Security, pension, or both? How much per month?
- If DISABLED: SSDI or VA benefits? How much per month? Are they a veteran?

WRAP UP: Thank them and let them know a loan officer will reach out shortly.

TRANSFER RULE: If at any point the caller insists on speaking to a loan officer, say "Absolutely, let me connect you right now — one moment please!" and then say the exact phrase: "TRANSFER_TO_LOAN_OFFICER". This will trigger the transfer.`;

const fastify = Fastify({ logger: true });
fastify.register(fastifyFormBody);
fastify.register(fastifyWs);

// Store active call sessions
const sessions = new Map();

// Health check
fastify.get('/', async () => ({ status: 'Jessica - NEXA Lending AI Agent is running' }));

// Twilio hits this when a call comes in — returns TwiML to start a media stream
fastify.post('/incoming-call', async (req, reply) => {
  const callSid = req.body?.CallSid || 'unknown';
  const callerNumber = req.body?.From || 'unknown';
  
  fastify.log.info(`Incoming call from ${callerNumber}, SID: ${callSid}`);
  
  const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Connect>
    <Stream url="wss://${req.headers.host}/media-stream">
      <Parameter name="callSid" value="${callSid}" />
      <Parameter name="callerNumber" value="${callerNumber}" />
    </Stream>
  </Connect>
</Response>`;

  reply.header('Content-Type', 'text/xml');
  return twiml;
});

// Twilio calls this when the call ends — for status updates
fastify.post('/call-status', async (req, reply) => {
  const callSid = req.body?.CallSid;
  const status = req.body?.CallStatus;
  fastify.log.info(`Call ${callSid} status: ${status}`);
  
  if (status === 'completed' && sessions.has(callSid)) {
    const session = sessions.get(callSid);
    // Post-call processing
    await processEndOfCall(session);
    sessions.delete(callSid);
  }
  
  return { ok: true };
});

// WebSocket endpoint — bridges Twilio audio <-> OpenAI Realtime
fastify.register(async (fastify) => {
  fastify.get('/media-stream', { websocket: true }, async (twilioWs, req) => {
    fastify.log.info('Twilio media stream connected');

    let callSid = null;
    let callerNumber = null;
    let streamSid = null;
    let transferRequested = false;
    const conversationHistory = [];

    // Connect to OpenAI Realtime API
    const openaiWs = new WebSocket(
      'wss://api.openai.com/v1/realtime?model=gpt-4o-realtime-preview-2024-10-01',
      {
        headers: {
          Authorization: `Bearer ${OPENAI_API_KEY}`,
          'OpenAI-Beta': 'realtime=v1',
        },
      }
    );

    // When OpenAI connects, configure the session
    openaiWs.on('open', () => {
      fastify.log.info('Connected to OpenAI Realtime API');
      
      const sessionConfig = {
        type: 'session.update',
        session: {
          turn_detection: { type: 'server_vad' },
          input_audio_format: 'g711_ulaw',
          output_audio_format: 'g711_ulaw',
          voice: 'alloy',
          instructions: SYSTEM_PROMPT,
          modalities: ['text', 'audio'],
          temperature: 0.8,
        },
      };
      openaiWs.send(JSON.stringify(sessionConfig));

      // Send initial greeting
      const greeting = {
        type: 'conversation.item.create',
        item: {
          type: 'message',
          role: 'user',
          content: [{ type: 'input_text', text: 'Start the conversation by greeting the caller warmly.' }],
        },
      };
      openaiWs.send(JSON.stringify(greeting));
      openaiWs.send(JSON.stringify({ type: 'response.create' }));
    });

    // Forward OpenAI audio back to Twilio
    openaiWs.on('message', async (data) => {
      try {
        const event = JSON.parse(data);

        if (event.type === 'session.updated') {
          fastify.log.info('OpenAI session configured');
        }

        // Stream audio back to Twilio
        if (event.type === 'response.audio.delta' && event.delta && streamSid) {
          const audioMsg = {
            event: 'media',
            streamSid,
            media: { payload: event.delta },
          };
          if (twilioWs.readyState === WebSocket.OPEN) {
            twilioWs.send(JSON.stringify(audioMsg));
          }
        }

        // Capture transcript for logging
        if (event.type === 'response.audio_transcript.done') {
          conversationHistory.push({ role: 'assistant', text: event.transcript });
          
          // Check if Jessica said the transfer phrase
          if (event.transcript && event.transcript.includes('TRANSFER_TO_LOAN_OFFICER')) {
            transferRequested = true;
            fastify.log.info('Transfer requested — initiating call transfer');
            await initiateTransfer(callSid, callerNumber);
          }
        }

        if (event.type === 'conversation.item.input_audio_transcription.completed') {
          conversationHistory.push({ role: 'user', text: event.transcript });
        }

        if (event.type === 'error') {
          fastify.log.error('OpenAI error:', event.error);
        }
      } catch (err) {
        fastify.log.error('Error processing OpenAI message:', err);
      }
    });

    openaiWs.on('close', () => fastify.log.info('OpenAI WebSocket closed'));
    openaiWs.on('error', (err) => fastify.log.error('OpenAI WS error:', err));

    // Handle messages from Twilio
    twilioWs.on('message', async (message) => {
      try {
        const data = JSON.parse(message);

        switch (data.event) {
          case 'start':
            streamSid = data.start.streamSid;
            callSid = data.start.callSid;
            callerNumber = data.start.customParameters?.callerNumber || 'unknown';
            
            fastify.log.info(`Stream started: sid=${streamSid}, caller=${callerNumber}`);
            
            // Store session
            sessions.set(callSid, {
              callSid,
              callerNumber,
              streamSid,
              conversationHistory,
              startTime: new Date().toISOString(),
            });
            break;

          case 'media':
            // Forward caller audio to OpenAI
            if (openaiWs.readyState === WebSocket.OPEN) {
              const audioAppend = {
                type: 'input_audio_buffer.append',
                audio: data.media.payload,
              };
              openaiWs.send(JSON.stringify(audioAppend));
            }
            break;

          case 'stop':
            fastify.log.info('Twilio stream stopped');
            if (openaiWs.readyState === WebSocket.OPEN) {
              openaiWs.close();
            }
            
            // Process end of call
            if (callSid && sessions.has(callSid)) {
              const session = sessions.get(callSid);
              session.conversationHistory = conversationHistory;
              session.endTime = new Date().toISOString();
              await processEndOfCall(session);
              sessions.delete(callSid);
            }
            break;
        }
      } catch (err) {
        fastify.log.error('Error processing Twilio message:', err);
      }
    });

    twilioWs.on('close', () => {
      fastify.log.info('Twilio WebSocket closed');
      if (openaiWs.readyState === WebSocket.OPEN) {
        openaiWs.close();
      }
    });
  });
});

// Transfer the call to Brandyn's cell via Twilio
async function initiateTransfer(callSid, callerNumber) {
  try {
    const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say>Please hold while I connect you to Brandyn, your loan officer at NEXA Lending.</Say>
  <Dial>${BRANDYN_CELL}</Dial>
</Response>`;

    const formData = new URLSearchParams();
    formData.append('Twiml', twiml);

    const res = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Calls/${callSid}.json`,
      {
        method: 'POST',
        headers: {
          Authorization: 'Basic ' + Buffer.from(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`).toString('base64'),
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formData,
      }
    );

    if (!res.ok) {
      const err = await res.text();
      console.error('Transfer failed:', err);
    } else {
      console.log(`Call ${callSid} transferred to ${BRANDYN_CELL}`);
    }
  } catch (err) {
    console.error('Transfer error:', err);
  }
}

// Post-call: extract intake with GPT, log to LeadFlow + MortgageFlow, send email
async function processEndOfCall(session) {
  try {
    const { callSid, callerNumber, conversationHistory, startTime, endTime } = session;
    
    const transcript = conversationHistory
      .map(m => `${m.role === 'assistant' ? 'AI' : 'User'}: ${m.text}`)
      .join('\n');

    const startDate = startTime ? new Date(startTime) : new Date();
    const endDate = endTime ? new Date(endTime) : new Date();
    const durationSecs = Math.round((endDate - startDate) / 1000);
    const duration = `${Math.floor(durationSecs / 60)}m ${durationSecs % 60}s`;
    const callTime = startDate.toLocaleString('en-US', { timeZone: 'America/Phoenix' });

    // Extract intake with GPT-4o
    let intake = {};
    try {
      const openaiRes = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${OPENAI_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-4o',
          messages: [
            {
              role: 'system',
              content: `Extract mortgage intake information from this call transcript and return as JSON.
Fields (use null if not mentioned):
- goal, amount_owed, current_interest_rate, current_mortgage_payment,
  taxes_insurance_included (boolean), annual_property_taxes, annual_homeowners_insurance,
  employer_name, years_employed, employment_status (employed/self_employed/retired/disabled),
  annual_income, taxable_income_last_year, taxable_income_year_before,
  call_notes (1-3 sentences on conversation tone, key info, caller attitude)
Return ONLY valid JSON.`,
            },
            { role: 'user', content: `TRANSCRIPT:\n${transcript}` },
          ],
          response_format: { type: 'json_object' },
        }),
      });
      if (openaiRes.ok) {
        const d = await openaiRes.json();
        intake = JSON.parse(d.choices[0].message.content);
      }
    } catch (e) {
      console.error('GPT extraction error:', e);
    }

    const callNotes = intake.call_notes || 'No summary available.';
    const callerPhoneClean = callerNumber.replace(/\D/g, '').replace(/^1/, '');

    // Post to our Base44 webhook for LeadFlow + MortgageFlow logging
    if (BASE44_WEBHOOK_URL) {
      await fetch(BASE44_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: {
            type: 'end-of-call-report',
            transcript,
            summary: callNotes,
            durationSeconds: durationSecs,
            call: {
              customer: { number: callerNumber },
              createdAt: startTime,
            },
          },
        }),
      });
    }

    console.log(`Post-call processing complete for ${callerNumber}`);
  } catch (err) {
    console.error('Post-call processing error:', err);
  }
}

fastify.listen({ port: PORT, host: '0.0.0.0' }, (err) => {
  if (err) {
    fastify.log.error(err);
    process.exit(1);
  }
  fastify.log.info(`Jessica bridge server running on port ${PORT}`);
});
